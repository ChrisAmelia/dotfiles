To run the homework, move into 'src' folder:
    $ cd src

Then simply run:
    $ make run

The second part of the homework, regarding to JUnit tests haven't been done.
