import java.util.ArrayList;
import java.util.List;

import com.google.common.collect.Lists;

public class Homework {

	/**
	 * Returns a partitioned list of the given list.
	 * 
	 * @param      <K>
	 * @param list list to partition
	 * @param size size of the sub-lists
	 * @return partitioned list
	 */
	public static <K> List<List<K>> partition(List<K> list, int size) {
		return Lists.partition(list, size);
	}

	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		System.out.println("Initial list: [1,2,3,4,5]");
		
		List<List<Integer>> partitioned = Lists.partition(list, 2);
		System.out.println("Partition size 2, result:" + partitioned.toString());
		
		List<List<Integer>> partitioned2 = Lists.partition(list, 3);
		System.out.println("Partition size 3, result:" + partitioned2.toString());
		
		List<List<Integer>> partitioned3 = Lists.partition(list, 1);
		System.out.println("Partition size 1, result:" + partitioned3.toString());
	}
}
